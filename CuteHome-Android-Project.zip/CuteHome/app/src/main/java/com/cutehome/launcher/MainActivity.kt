package com.cutehome.launcher

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(244, 240, 250)
    private val ink = Color.rgb(39, 35, 48)
    private lateinit var grid: GridLayout
    private lateinit var apps: List<android.content.pm.ResolveInfo>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        apps = loadApps()
        buildHome()
    }

    private fun loadApps(): List<android.content.pm.ResolveInfo> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = if (android.os.Build.VERSION.SDK_INT >= 33) packageManager.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0)) else @Suppress("DEPRECATION") packageManager.queryIntentActivities(intent, 0)
        return list.filter { it.activityInfo.packageName != packageName }.sortedBy { it.loadLabel(packageManager).toString().lowercase() }
    }

    private fun buildHome() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(8)); setBackgroundColor(bg) }
        val top = TextView(this).apply { text = "♡  Cute Home"; textSize = 22f; setTextColor(ink); typeface = Typeface.create("sans-serif-rounded", Typeface.BOLD); gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), dp(8), 0, dp(12)) }
        root.addView(top, LinearLayout.LayoutParams(-1, dp(48)))

        val music = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(12)); background = rounded(Color.rgb(232, 224, 246), 24) }
        val musicText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        musicText.addView(TextView(this).apply { text = "♫  MUSIC PLAYER"; textSize = 12f; setTextColor(Color.rgb(112, 94, 151)); typeface = Typeface.DEFAULT_BOLD })
        musicText.addView(TextView(this).apply { text = "แตะเพื่อเปิดแอปเพลง"; textSize = 15f; setTextColor(ink); setPadding(0, dp(5), 0, 0) })
        music.addView(musicText)
        music.addView(TextView(this).apply { text = "◀     ▶     ▶|"; textSize = 18f; setTextColor(ink); setPadding(dp(8), 0, dp(4), 0); setOnClickListener { openMusic() } })
        music.setOnClickListener { openMusic() }
        root.addView(music, LinearLayout.LayoutParams(-1, dp(88)))

        val label = TextView(this).apply { text = "แอปของฉัน"; textSize = 14f; setTextColor(Color.rgb(112, 104, 126)); setPadding(dp(4), dp(16), 0, dp(8)) }
        root.addView(label)
        val scroll = ScrollView(this)
        grid = GridLayout(this).apply { columnCount = 4; alignmentMode = GridLayout.ALIGN_BOUNDS; useDefaultMargins = false }
        scroll.addView(grid)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        addApps(apps)

        val dock = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(dp(6), dp(8), dp(6), dp(8)); background = rounded(Color.rgb(232, 224, 246), 25) }
        val dockItems = listOf("☎" to "โทรศัพท์", "●" to "ข้อความ", "◉" to "Chrome", "▣" to "กล้อง")
        dockItems.forEach { (symbol, name) ->
            val item = TextView(this).apply { text = "$symbol\n$name"; gravity = Gravity.CENTER; textSize = 19f; setTextColor(ink); setOnClickListener { launchByLabel(name) } }
            dock.addView(item, LinearLayout.LayoutParams(0, dp(58), 1f))
        }
        root.addView(dock, LinearLayout.LayoutParams(-1, dp(70)))
        setContentView(root)
    }

    private fun addApps(list: List<android.content.pm.ResolveInfo>) {
        grid.removeAllViews()
        list.forEachIndexed { index, info ->
            val cell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(3), dp(8), dp(3), dp(8)) }
            val icon = ImageView(this).apply { setImageDrawable(info.loadIcon(packageManager)); scaleType = ImageView.ScaleType.FIT_CENTER; background = rounded(Color.WHITE, 18); setPadding(dp(10), dp(10), dp(10), dp(10)) }
            cell.addView(icon, LinearLayout.LayoutParams(dp(54), dp(54)))
            cell.addView(TextView(this).apply { text = info.loadLabel(packageManager).toString(); textSize = 10.5f; setTextColor(ink); gravity = Gravity.CENTER; maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END; setPadding(0, dp(5), 0, 0) }, LinearLayout.LayoutParams(-1, dp(34)))
            cell.setOnClickListener { launch(info) }
            grid.addView(cell, GridLayout.LayoutParams().apply { width = 0; height = dp(100); columnSpec = GridLayout.spec(index % 4, 1f); setMargins(dp(2), dp(2), dp(2), dp(2)) })
        }
    }

    private fun launch(info: android.content.pm.ResolveInfo) {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setClassName(info.activityInfo.packageName, info.activityInfo.name)
        try { startActivity(i) } catch (_: Exception) { Toast.makeText(this, "เปิดแอปนี้ไม่ได้", Toast.LENGTH_SHORT).show() }
    }

    private fun launchByLabel(name: String) {
        val key = when (name) { "โทรศัพท์" -> listOf("phone", "dialer"); "ข้อความ" -> listOf("messag", "sms"); "Chrome" -> listOf("chrome", "browser"); else -> listOf("camera") }
        val found = apps.firstOrNull { info -> val s = (info.loadLabel(packageManager).toString() + " " + info.activityInfo.packageName).lowercase(); key.any { s.contains(it) } }
        if (found != null) launch(found) else Toast.makeText(this, "ไม่พบแอป$name ในเครื่อง", Toast.LENGTH_SHORT).show()
    }

    private fun openMusic() {
        val found = apps.firstOrNull { val s = (it.loadLabel(packageManager).toString() + " " + it.activityInfo.packageName).lowercase(); listOf("music", "spotify", "youtube", "เพลง").any { k -> s.contains(k) } }
        if (found != null) launch(found) else Toast.makeText(this, "ยังไม่พบแอปเพลง", Toast.LENGTH_SHORT).show()
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
