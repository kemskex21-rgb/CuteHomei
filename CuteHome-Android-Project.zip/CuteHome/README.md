# Cute Home — Android Launcher starter project

A lightweight Android HOME launcher styled after the supplied reference: soft lavender background, rounded music panel, app grid using installed app icons, and a four-item dock.

## Build an APK without a computer (GitHub Actions)
1. Download this ZIP and extract it on your phone.
2. Create a new empty repository on GitHub (for example `CuteHome`).
3. Upload the **contents inside the `CuteHome` folder** to the repository root. The `.github/workflows/build-apk.yml` file must also be uploaded; enable viewing hidden files if needed.
4. Open the repository on GitHub, go to **Actions**, select **Build Cute Home APK**, then tap **Run workflow**.
5. Wait for the workflow to finish successfully. Open that run and download the **CuteHome-debug-apk** artifact.
6. Extract the downloaded artifact ZIP, tap `app-debug.apk`, and allow installation from that source if Android asks.
7. Press Home and choose **Cute Home** as the default Home app. To switch back, use Settings > Apps > Default apps > Home app (wording may vary on MIUI/HyperOS).

## Build locally
Open the project in Android Studio, install Android SDK Platform 35 if prompted, then run `gradle assembleDebug`.

The GitHub workflow builds a debug APK; it is suitable for personal testing and is not a Play Store release. `QUERY_ALL_PACKAGES` is used so the launcher can list installed apps; Google Play distribution may require policy approval.
